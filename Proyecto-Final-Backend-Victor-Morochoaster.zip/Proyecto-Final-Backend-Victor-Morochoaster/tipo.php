<?php
  require('./filtro.php');
  $getData = leerDatos(); 
  obtnTipo($getData)
 ?>
